import React from 'react';

const Spinner = () => <div>Spinner</div>





export default Spinner;