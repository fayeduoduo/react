import React from 'react';


const Main = () => (
    <div>
        <img></img>
        <img></img>
        <img></img>
        <img></img>
    </div>
)

export default Main;