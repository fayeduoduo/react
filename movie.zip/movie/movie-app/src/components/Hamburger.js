import React from 'react';

class Hamburger extends React.Component {
        constructor(props) {
            super(props);
            this.state = {
                menuOpen: false,
            }
        }

        handleMenuClick() {
            this.setState({
                menuOpen: !this.state.menuOpen
            });
        }

        handleLinkClick() {
            this.setState({
                menuOpen: false
            });
        }
    }

export default Hamburger;