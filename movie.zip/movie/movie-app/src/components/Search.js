import React ,{useState, useRef} from 'react';
import FontAwesome from 'react-fontawesome';

// import { StyledSearchBar, StyledSearchBarContent} from '../styles/StyledSearchBar';


const Search = ({callback}) => {
    const [state,setState] = useState("");
    const timeOut = useRef(null);

    const doSearch = event => {
        const {value} = event.target;
    
        clearTimeout(timeOut.current);
        setState(value);

        timeOut.current = setTimeout(()=>{
            callback(value);
        },800);
    }

    return (
        <div className='search'>
            <FontAwesome name='search' className= 'icon' style={{ fontSize: "20px", color:"#fff"}}/>
            <input className='searchBar'type='text' 
            placeholder='Search for a movie...'
            onChange={doSearch}
            value={state}
            >

            </input>
        </div>
    )
}




export default Search;