import React from 'react';

const Favourites = () => (
    <h2>Favourite movies</h2>
)

export default Favourites;