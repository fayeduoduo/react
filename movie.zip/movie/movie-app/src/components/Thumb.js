import React from 'react';

const Thumb = ({image, movieId, clickable}) => (
    <div>
        {clickable? (
            <img className='clickable' src={image} alt='moviethumb' />
        ) : (
            <img src={image} alt='moviethumb' />
        )
    }
    </div>

)



export default Thumb;