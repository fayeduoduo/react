import React, { useState } from 'react';
import { POPULAR_BASE_URL, SEARCH_BASE_URL, IMAGE_BASE_URL, BACKDROP_SIZE, POSTER_SIZE} from '../globals/variables';
import Search from './Search';
import Spinner from './Spinner';
import FontAwesome from 'react-fontawesome';
import Grid from './Grid';
import Thumb from './Thumb';
import { DEFAULT_CATEGORY} from '../globals/variables';


//custome hook 
import { useHomeFetch } from './useHomeFetch';



const Home = () => {
    const [{ state:{movies, currentpage, totalPages}, loading, error}, fetchMovies] = useHomeFetch(); 
    const [searchTerm, setSearch] = useState ('');

    const searchMovies = search => {
        const endpoint = search? SEARCH_BASE_URL + search 
        : POPULAR_BASE_URL;
        setSearch(search);
        fetchMovies(endpoint);

    }
  
    return (
    <>
    
        <Search  callback={searchMovies}/>
        <Thumb  />
        <Grid header={searchTerm? 'Search Result':'Popular Movies'}>
         {movies.map(movie=>(
             <Thumb
             key={movie.id}
             clickable
             image={`${IMAGE_BASE_URL}${POSTER_SIZE}${movie.poster_path}`}
             movieId={movie.id}
             movieName={movie.original_title}/>
         ))
         }


        </Grid>
        <Spinner />
        <br />
        <div className='select'>
            <label> Choose &nbsp;
                <select className='selectInfo'>
                    <option>popular</option>
                    <option>Top rated</option>
                    <option>Now playing</option>
                    <option>Upcoming</option>
                </select>
            </label>
        </div>
    </>
)
    }

Home.defaultProps = {
    category:DEFAULT_CATEGORY
}

export default Home;