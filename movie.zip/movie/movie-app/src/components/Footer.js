import React from 'react';


const Footer = () => {


    const d= new Date();
    const y = d.getFullYear()


    return (
        <footer>
            <p>&copy; {y} The Movie DB all rights reserved.</p>
            <p>Created by Faye Liu, Tina Liu, XuanYe Cheng</p>
        </footer>
    )
}

export default Footer;