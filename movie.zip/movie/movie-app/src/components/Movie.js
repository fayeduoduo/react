import React from 'react';


const Movie =({ movieId }) => <div className='header'><p>Movie:{movieId} </p></div>


export default Movie;