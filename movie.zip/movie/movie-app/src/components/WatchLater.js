import React from 'react';

const WatchLater = ()=> (
    <p>Use + to add your movies here...</p>
)

export default WatchLater;