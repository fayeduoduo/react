import React from "react";
import {Link } from "react-router-dom";
import '../styles/styles.scss';


const Header = () => 
<div className='header'>
    <h1 className='title'>
    <Link to = "/">
        The Movie DB
    </Link>
    </h1>
    <div className="hamburger">
        <span></span>
        <span></span>
        <span></span>
    </div>
</div>




export default Header;

// class Header extends React.Component {
//     render () {
//         return (
//          <div className='header'>
//             <h1>The Movie DB</h1>
//             <div className="hamburger">
//                 <span></span>
//                 <span></span>
//                 <span></span>
//             </div>
//         </div>
//         )
//     }


// }
