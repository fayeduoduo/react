import React from 'react';

const NotFound =() => <div>404....nothing found here....</div>


export default NotFound;