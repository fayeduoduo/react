import React from 'react';
import '../styles/styles.scss';


const Grid = ({header, children})  => (
    <div className='grid'>
        <h1 className='header'>{header}</h1>
     <div className='grid-content'>{children}</div>

        
    </div>

    
)


export default Grid;