import React from 'react';
import { BrowserRouter as Router, Switch, Route} from "react-router-dom";

import Header from '../components/Header';

import Nav from '../components/Nav';
import Footer from '../components/Footer';
import Main from '../components/Main';

//Pages
import Home from '../components/Home';
import About from '../components/About';
import Favourites from '../components/Favourites';
import WatchLater from '../components/WatchLater';


import NotFound from '../components/NotFound';
import Movie from '../components/Movie';

const AppRouter = () => (

        <Router>

            <div className= "wrapper">
               <Header /> 
               <Nav />  
               <Switch>
                   
                   <Route path={'/'} exact><Home /></Route>        
                   <Route path={'/about'}><About /></Route>
                   <Route path="/:movieId"><Movie /></Route>
                   <Route path={'/favourite'}><Favourites /></Route>
                   <Route path={'/watch later'}><WatchLater /></Route>
                   
                   <Route><NotFound default/></Route>
               </Switch>
               <Main />
               <Footer />
            </div>
        </Router>
    )





export default AppRouter;