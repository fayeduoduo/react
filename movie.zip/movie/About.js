import React from 'react';
import Logo from './db-logo.jpg';
import boy from './boy.png';
import girl1 from './girl-1.png';
import girl2 from './girl-2.png';

const About = () => (
    <div className="about">
        
        <div>
            <h4>About the project</h4>
                <p>MVDB is a Movie Database listing the moviesbased on popularity, rating, and release date. Browse for your favourite film, add it to the Favourite List, and save it for the Watch Later list!</p>
                <p><span className="star">☆ </span>This product uses the TMDb APIbut is not endorsed or certified by TMDB.</p>
                <img className="logo" src={Logo} alt="db-logo" />


        </div>
        <div>
            <h4>Meet the team</h4>
                <p>MDN is a React JS project proudly created by <span className="faye">Faye</span>, <span className="tina">Tina</span>, and <span className="shawn">Shawn</span>. We are an ambitious web development team who love coding, designing best user experience, and challenging!</p>
                <div className="portraits">
                <img className="boy" src={boy} alt="boy" />
                <img className="girl1" src={girl1} alt="girl1" />
                <img className="girl2" src={girl2} alt="girl2" />
                </div>
        </div>
    </div>
 
    // <div className='about'>
    //     <h3>Welcome to Movie DB!</h3>
    //     <div className='projecInfo'>
    //         <h4>About the project</h4>
    //         <p>The Movie DB is a movie database listing the movies based orphans
    //             rating and popularity.Browse you favourite movies and save it 
    //             for the watch later.</p>
    //         <p>This product uses the MDN API is but is not endorsed or certified 
    //             by MDN.</p>
    //     </div>
    //     <div className='memberInfo'>
    //         <h4>Team member</h4>
    //         <div>
    //             <img></img>
    //             <span>Faye Liu</span>
    //         </div>
    //         <div>
    //             <img></img>
    //             <span>Tina Liu</span>
    //         </div>
    //         <div>
    //             <img></img>
    //             <span>XuanYe Cheng</span>
    //         </div>
    //     </div>
    // </div>
)


export default About;